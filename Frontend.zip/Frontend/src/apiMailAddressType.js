export const API_BASE_URL = "https://crm5-backend-ayfdhhgubsaybmfj.germanywestcentral-01.azurewebsites.net/api";
const FIELD_LABELS = {
    description: "Descrizione",
    priority: "Priorita"
};
function normalizeKey(rawKey) {
    return rawKey.trim().toLowerCase().replace(/\[(\d+)\]/g, "");
}
function mapFieldName(rawKey) {
    const key = normalizeKey(rawKey);
    if (FIELD_LABELS[key]) {
        return FIELD_LABELS[key];
    }
    const cleaned = key.replace(/\./g, " ");
    return cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
}
async function parseMissingFields(response) {
    var _a, _b;
    const contentType = (_b = (_a = response.headers.get("content-type")) === null || _a === void 0 ? void 0 : _a.toLowerCase()) !== null && _b !== void 0 ? _b : "";
    if (!contentType.includes("application/json")) {
        return [];
    }
    let body = null;
    try {
        body = await response.json();
    }
    catch (_c) {
        return [];
    }
    if (!(body === null || body === void 0 ? void 0 : body.errors)) {
        return [];
    }
    const keys = Object.keys(body.errors);
    return Array.from(new Set(keys.map(mapFieldName)));
}
async function fetchJson(url, init) {
    const response = await fetch(url, Object.assign({ headers: {
            "Content-Type": "application/json"
        } }, init));
    if (!response.ok) {
        const errorBody = await response.text();
        throw new Error(errorBody || `HTTP ${response.status}`);
    }
    if (response.status === 204) {
        return undefined;
    }
    return response.json();
}
async function handleTypeUpsertResponse(response) {
    if (response.ok) {
        return;
    }
    const missingFields = await parseMissingFields(response);
    if (missingFields.length > 0) {
        throw new Error(`MISSING_FIELDS:${missingFields.join("|")}`);
    }
    const errorBody = await response.text();
    throw new Error(errorBody || `HTTP ${response.status}`);
}
export function getMailAddressTypes() {
    return fetchJson(`${API_BASE_URL}/MailAddressType/all`);
}
export function createMailAddressType(payload) {
    return fetch(`${API_BASE_URL}/MailAddressType`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
    }).then(handleTypeUpsertResponse);
}
export function updateMailAddressType(typeId, payload) {
    return fetch(`${API_BASE_URL}/MailAddressType/${typeId}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
    }).then(handleTypeUpsertResponse);
}
export function deleteMailAddressType(typeId) {
    return fetch(`${API_BASE_URL}/MailAddressType/${typeId}`, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json"
        }
    }).then(async (response) => {
        if (response.ok) {
            return;
        }
        const errorBody = await response.text();
        throw new Error(errorBody || `HTTP ${response.status}`);
    });
}
